export const environment = {
  production: true,
  title: 'Local Environment Heading',

   apiURL: 'http://preprod.ngser.com:1802'
};
